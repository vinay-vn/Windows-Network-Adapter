Step1: Edit "Network Adapter" file and replace network adapter name with your network adapter.
Step2: Copy "Network Adapter" file and paste in proper Location 
       like C:/Script/Network Adapter.
Step3: Copy Network Adapter File for that path location and paste shortcut on desktop.
Step4: Open Network Adapter-Shortcut properties and navigate Shortcut>Advanced and check on "Run as Administrator" and Apply.